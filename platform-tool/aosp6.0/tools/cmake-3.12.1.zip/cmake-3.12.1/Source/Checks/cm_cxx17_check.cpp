#include <cstdio>
#include <unordered_map>

int main()
{
  return 0;
}
